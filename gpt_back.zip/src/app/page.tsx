import { askClaude } from "./api";
import { marked } from "marked";
// import type { NextApiRequest, NextApiResponse } from "next";

export default async function Home() {
  const response = await askClaude("Hello, how are you?");
  return (
    <div dangerouslySetInnerHTML={{ __html: marked(response) }}>
    
    </div>
  );
}

